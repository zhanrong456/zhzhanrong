insert into ttrss_themes (theme_name, theme_path) values ('Three-pane', '3pane');

update ttrss_version set schema_version = 25;
